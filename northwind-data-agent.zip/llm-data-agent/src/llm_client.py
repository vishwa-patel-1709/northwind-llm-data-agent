"""
llm_client.py
-------------
Talks to a locally running Ollama server (http://localhost:11434) to turn
plain-English questions into SQL, and later, results into plain-English
summaries.

Ollama exposes a simple local HTTP API once it's running (`ollama serve`,
which the desktop app starts automatically). We don't need any API key
because nothing leaves your machine.
"""

import re
import requests

OLLAMA_URL = "http://localhost:11434/api/generate"
DEFAULT_MODEL = "qwen2.5-coder:3b"


def build_sql_prompt(question: str, schema: str) -> str:
    """
    Combines the database schema + the user's question + formatting rules
    into a single prompt string for the LLM.
    """
    return f"""You are an expert SQLite query generator. You are given a
database schema and a question in plain English. Reply with ONLY a single
valid SQLite SELECT query that answers the question. Do not include any
explanation, comments, or markdown code fences. Do not modify any data
(no INSERT/UPDATE/DELETE).

Rules:
- Table names with spaces (like "Order Details") MUST be wrapped in double quotes.
- Use JOINs when the question needs data from more than one table.
- Prefer LIMIT clauses for "top N" style questions.

Example 1:
Question: What are the 3 most expensive products?
SQL: SELECT ProductName, UnitPrice FROM Products ORDER BY UnitPrice DESC LIMIT 3

Example 2 (a table name with a space — note the required double quotes):
Question: What is the average order value by shipping country?
SQL: SELECT o.ShipCountry, AVG(od.UnitPrice * od.Quantity) AS AvgOrderValue FROM "Order Details" od JOIN Orders o ON od.OrderID = o.OrderID GROUP BY o.ShipCountry

Database schema:
{schema}

Question: {question}
SQL:"""


def extract_sql(raw_text: str) -> str:
    """
    Cleans up whatever text the model returned so we're left with just the
    SQL statement, even if the model ignored our formatting instructions.

    Handles three common cases:
      1. Plain SQL (ideal case, nothing to do)
      2. SQL wrapped in ```sql ... ``` or ``` ... ``` code fences
      3. A short explanation sentence before/after the actual query
    """
    text = raw_text.strip()

    # Case 2: strip markdown code fences if present
    fence_match = re.search(r"```(?:sql)?\s*(.*?)```", text, re.DOTALL | re.IGNORECASE)
    if fence_match:
        text = fence_match.group(1).strip()

    # Case 3: if there's still extra prose, pull out the first SELECT ...
    # statement (up to a semicolon or end of string).
    select_match = re.search(r"(SELECT.*?)(;|\Z)", text, re.DOTALL | re.IGNORECASE)
    if select_match:
        text = select_match.group(1).strip()

    return text


def call_ollama(prompt: str, model: str = DEFAULT_MODEL) -> str:
    """
    Sends a prompt to the local Ollama server and returns the raw text
    response. Raises a friendly error if Ollama isn't running.
    """
    try:
        response = requests.post(
            OLLAMA_URL,
            json={"model": model, "prompt": prompt, "stream": False},
            timeout=60,
        )
        response.raise_for_status()
    except requests.exceptions.ConnectionError:
        raise RuntimeError(
            "Couldn't reach Ollama at http://localhost:11434 — "
            "is it running? Try `ollama serve` in a terminal, or open the "
            "Ollama desktop app."
        )

    return response.json()["response"]


def generate_sql(question: str, schema: str, model: str = DEFAULT_MODEL) -> str:
    """The main function: question + schema in, clean SQL string out."""
    prompt = build_sql_prompt(question, schema)
    raw = call_ollama(prompt, model=model)
    return extract_sql(raw)


def generate_summary(question: str, result_preview: str, model: str = DEFAULT_MODEL) -> str:
    """
    Given the original question and a small text preview of the result
    (e.g. a few rows of a DataFrame), asks the model for a one/two-sentence
    plain-English takeaway a non-technical reader could understand.
    """
    prompt = f"""You answered a data question by running a SQL query.
Write a single short, plain-English sentence (no more than 2 sentences)
summarizing the key insight for a business audience. Do not mention SQL.

Question: {question}
Result data:
{result_preview}

Summary:"""
    return call_ollama(prompt, model=model).strip()
