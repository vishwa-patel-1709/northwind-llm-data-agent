"""
chart.py
--------
Turns a pandas DataFrame (the result of a SQL query) into a matplotlib chart.

We don't always draw the same chart type — the right chart depends on the
*shape* of the data (this is a real data-viz principle, not just a coding
convenience): a single number should not be a one-bar bar chart, a
category-vs-amount table wants a bar chart, and a date-vs-amount table wants
a line chart. pick_chart() below applies that logic automatically.

Colors are a small fixed palette (not matplotlib's default rainbow cycle) so
results always look consistent and stay readable for colorblind viewers.
"""

import matplotlib
matplotlib.use("Agg")  # render to file/buffer, no GUI needed
import matplotlib.pyplot as plt
import pandas as pd

# A trimmed version of a validated categorical palette (see project notes) —
# used in fixed order, never cycled/reassigned.
COLORS = {
    "blue": "#2a78d6",
    "orange": "#eb6834",
    "aqua": "#1baf7a",
    "yellow": "#eda100",
}
CATEGORICAL_ORDER = ["blue", "orange", "aqua", "yellow"]

INK_PRIMARY = "#0b0b0b"
INK_SECONDARY = "#52514e"
INK_MUTED = "#898781"
GRIDLINE = "#e1e0d9"
SURFACE = "#fcfcfb"

MAX_BAR_CATEGORIES = 15


def _style_axes(ax):
    """Shared 'clean chart' styling: recessive gridlines, no box, muted ticks."""
    ax.set_facecolor(SURFACE)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    ax.spines["bottom"].set_color(INK_MUTED)
    ax.tick_params(colors=INK_SECONDARY, labelsize=9)
    ax.yaxis.grid(True, color=GRIDLINE, linewidth=1)
    ax.set_axisbelow(True)


def pick_chart(df: pd.DataFrame):
    """
    Decides what to draw based on the shape of the query result.

    Returns a matplotlib Figure, or None if this result is better shown as
    a plain table (e.g. too many columns, or a single value with nothing to
    compare against).
    """
    if df.empty:
        return None

    numeric_cols = df.select_dtypes(include="number").columns.tolist()
    non_numeric_cols = [c for c in df.columns if c not in numeric_cols]

    # Single row, single numeric value -> this is a "stat", not a chart.
    if len(df) == 1 and len(numeric_cols) == 1:
        return None

    if len(non_numeric_cols) == 1:
        label_col = non_numeric_cols[0]
        is_date = _looks_like_date(df[label_col])

        # IMPORTANT: the date check must happen BEFORE the generic bar-chart
        # case below. Otherwise a monthly/yearly time column gets treated as
        # a plain category, sorted by value instead of chronologically, and
        # the resulting "line chart" comes out with months in the wrong
        # order. (Caught this exact bug by rendering a test chart — always
        # look at the actual image, not just "did it return a figure".)
        if is_date and len(numeric_cols) == 1:
            return _line_chart(df, label_col, numeric_cols[0])

        if not is_date and len(numeric_cols) == 1:
            return _bar_chart(df, label_col, numeric_cols[0])

        # One label column + a few numeric columns -> grouped bar (categorical colors).
        if 2 <= len(numeric_cols) <= 4:
            return _grouped_bar_chart(df, label_col, numeric_cols)

    # Anything more complex: let the caller fall back to a plain table.
    return None


def _looks_like_date(series: pd.Series) -> bool:
    import warnings
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            pd.to_datetime(series, errors="raise")
        return True
    except (ValueError, TypeError):
        return False


def _bar_chart(df, label_col, value_col):
    plot_df = df.head(MAX_BAR_CATEGORIES).sort_values(value_col, ascending=True)
    horizontal = plot_df[label_col].astype(str).str.len().max() > 10

    fig, ax = plt.subplots(figsize=(7, max(3, 0.4 * len(plot_df))))
    _style_axes(ax)

    if horizontal:
        ax.barh(plot_df[label_col].astype(str), plot_df[value_col], color=COLORS["blue"])
        ax.xaxis.grid(True, color=GRIDLINE, linewidth=1)
        ax.yaxis.grid(False)
    else:
        ax.bar(plot_df[label_col].astype(str), plot_df[value_col], color=COLORS["blue"])
        plt.xticks(rotation=30, ha="right")

    ax.set_title(f"{value_col} by {label_col}", color=INK_PRIMARY, fontsize=11, loc="left")
    fig.tight_layout()
    return fig


def _line_chart(df, date_col, value_col):
    plot_df = df.copy()
    plot_df[date_col] = pd.to_datetime(plot_df[date_col])
    plot_df = plot_df.sort_values(date_col)

    fig, ax = plt.subplots(figsize=(7, 4))
    _style_axes(ax)
    ax.plot(plot_df[date_col], plot_df[value_col], color=COLORS["blue"], linewidth=2)
    ax.set_title(f"{value_col} over time", color=INK_PRIMARY, fontsize=11, loc="left")
    fig.autofmt_xdate()
    fig.tight_layout()
    return fig


def _grouped_bar_chart(df, label_col, value_cols):
    plot_df = df.head(MAX_BAR_CATEGORIES)
    x = range(len(plot_df))
    n = len(value_cols)
    width = 0.8 / n

    fig, ax = plt.subplots(figsize=(8, 4.5))
    _style_axes(ax)

    for i, col in enumerate(value_cols):
        hue = COLORS[CATEGORICAL_ORDER[i % len(CATEGORICAL_ORDER)]]
        offsets = [xi + (i - (n - 1) / 2) * width for xi in x]
        ax.bar(offsets, plot_df[col], width=width, label=col, color=hue)

    ax.set_xticks(list(x))
    ax.set_xticklabels(plot_df[label_col].astype(str), rotation=30, ha="right")
    ax.legend(frameon=False, labelcolor=INK_SECONDARY, fontsize=9)
    ax.set_title(", ".join(value_cols) + f" by {label_col}", color=INK_PRIMARY, fontsize=11, loc="left")
    fig.tight_layout()
    return fig
