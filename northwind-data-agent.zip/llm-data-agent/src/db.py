"""
db.py
-----
Everything related to talking to the Northwind SQLite database:

1. get_schema_description() — reads the database's own metadata and turns it
   into a plain-text block we can hand to the LLM, so it "knows" what tables
   and columns exist before it tries to write SQL.

2. run_query() — safely executes a SQL string (that the LLM will generate)
   and returns the results as a pandas DataFrame. "Safely" means: we only
   ever allow read-only SELECT queries. The LLM's output is just text it
   generated — we never trust it blindly, the same way you'd never trust
   raw user input in a web form.
"""

import sqlite3
import re
import pandas as pd

DB_PATH = "data/northwind.db"


def get_table_names(db_path: str = DB_PATH) -> list:
    """Returns every real table name in the database (skips SQLite's own
    internal sqlite_* bookkeeping tables)."""
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute(
        "SELECT name FROM sqlite_master WHERE type='table' "
        "AND name NOT LIKE 'sqlite_%' ORDER BY name;"
    )
    names = [row[0] for row in cur.fetchall()]
    conn.close()
    return names


def get_schema_description(db_path: str = DB_PATH) -> str:
    """
    Inspects the SQLite database and returns a human/LLM-readable text
    description of every table and its columns, e.g.:

        Table: Orders
          - OrderID (INTEGER)
          - CustomerID (TEXT)
          - EmployeeID (INTEGER)
          - OrderDate (DATE)
          ...

    This is built dynamically from the database itself (not hand-typed),
    so if the schema ever changes, this description updates automatically.
    """
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    tables = get_table_names(db_path)

    lines = []
    for table in tables:
        # PRAGMA table_info is SQLite's built-in way to ask "what columns
        # does this table have, and what type is each one?"
        cur.execute(f'PRAGMA table_info("{table}")')
        columns = cur.fetchall()  # each row: (cid, name, type, notnull, dflt, pk)

        lines.append(f"Table: {table}")
        for col in columns:
            col_name, col_type = col[1], col[2]
            pk_marker = " [PRIMARY KEY]" if col[5] else ""
            lines.append(f"  - {col_name} ({col_type}){pk_marker}")
        lines.append("")  # blank line between tables

    conn.close()
    return "\n".join(lines)


# A short allowlist check: the LLM should only ever produce SELECT queries.
# This is a simple guard, not a bulletproof SQL parser — good enough for a
# learning project, and we'll explain the tradeoffs when we build this out.
_FORBIDDEN_KEYWORDS = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|REPLACE|ATTACH|PRAGMA)\b",
    re.IGNORECASE,
)


class UnsafeQueryError(Exception):
    """Raised when the generated SQL isn't a safe, read-only SELECT."""
    pass


def _quote_multiword_table_names(sql: str, db_path: str) -> str:
    """
    SQLite requires double-quotes around any table name that contains a
    space — Northwind has exactly one: "Order Details". Small local models
    are told about this in the prompt, but don't always remember it, and
    the failure looks like: near "Order": syntax error.

    Rather than relying purely on the model getting the prompt right every
    time, we fix it defensively here, right before execution: look up
    which table names (dynamically, from the database itself — this isn't
    hardcoded to "Order Details" specifically) contain a space, and wrap
    any unquoted occurrence of one in double quotes.
    """
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE '% %'")
    multiword_tables = [row[0] for row in cur.fetchall()]
    conn.close()

    for name in multiword_tables:
        # Negative look-behind/ahead for a quote character skips names that
        # are already correctly quoted, so this is safe to run every time.
        pattern = re.compile(r'(?<!")\b' + re.escape(name) + r'\b(?!")', re.IGNORECASE)
        sql = pattern.sub(f'"{name}"', sql)

    return sql


def run_query(sql: str, db_path: str = DB_PATH) -> pd.DataFrame:
    """
    Executes a SQL string against the database and returns a DataFrame.
    Raises UnsafeQueryError if the query looks like anything other than
    a plain read-only SELECT.
    """
    sql = _quote_multiword_table_names(sql, db_path)
    cleaned = sql.strip().rstrip(";")

    if not cleaned.lower().startswith("select"):
        raise UnsafeQueryError("Only SELECT queries are allowed.")

    if _FORBIDDEN_KEYWORDS.search(cleaned):
        raise UnsafeQueryError("Query contains a disallowed keyword.")

    if ";" in cleaned:
        # Blocks "stacked" queries like: SELECT ...; DROP TABLE ...
        raise UnsafeQueryError("Multiple statements are not allowed.")

    conn = sqlite3.connect(db_path)
    try:
        df = pd.read_sql_query(cleaned, conn)
    finally:
        conn.close()

    return df


if __name__ == "__main__":
    # Quick manual test: run this file directly with `python src/db.py`
    print(get_schema_description())
