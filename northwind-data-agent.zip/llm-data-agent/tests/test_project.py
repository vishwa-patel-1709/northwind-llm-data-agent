"""
A small test suite covering the parts of this project that don't require a
running Ollama server — schema introspection, SQL safety, the LLM response
parser, and chart-type selection. This is the kind of thing worth having in
a portfolio repo: it shows you validate your own code instead of only
eyeballing it.

Run with:  pytest
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import patch

from src.db import get_schema_description, run_query, UnsafeQueryError
from src.llm_client import extract_sql, generate_sql
from src.chart import pick_chart


def test_schema_description_lists_known_tables():
    schema = get_schema_description()
    assert "Table: Orders" in schema
    assert "Table: Products" in schema
    assert "Table: Customers" in schema


def test_run_query_returns_real_data():
    df = run_query("SELECT COUNT(*) AS n FROM Customers")
    assert df.iloc[0]["n"] == 93


def test_run_query_auto_quotes_forgotten_order_details():
    """
    Regression test for a real failure seen with qwen2.5-coder:3b: it
    sometimes forgets to quote "Order Details" (the one table name with a
    space), which used to blow up with 'near "Order": syntax error'.
    run_query() should now fix this automatically before executing.
    """
    unquoted_sql = (
        "SELECT o.ShipCountry, AVG(od.UnitPrice * od.Quantity) AS AvgOrderValue "
        "FROM Order Details od JOIN Orders o ON od.OrderID = o.OrderID "
        "GROUP BY o.ShipCountry"
    )
    df = run_query(unquoted_sql)  # should NOT raise
    assert "ShipCountry" in df.columns
    assert len(df) > 0


@pytest.mark.parametrize("bad_sql", [
    "DELETE FROM Orders",
    "DROP TABLE Customers",
    "SELECT * FROM Customers; DELETE FROM Orders",
    "UPDATE Products SET UnitPrice = 0",
])
def test_run_query_blocks_unsafe_sql(bad_sql):
    with pytest.raises(UnsafeQueryError):
        run_query(bad_sql)


@pytest.mark.parametrize("raw,expected", [
    ("SELECT 1", "SELECT 1"),
    ("```sql\nSELECT 1\n```", "SELECT 1"),
    ("```\nSELECT 1\n```", "SELECT 1"),
    ("Sure, here you go:\nSELECT 1;\nHope that helps!", "SELECT 1"),
])
def test_extract_sql_handles_common_model_response_styles(raw, expected):
    assert extract_sql(raw) == expected


def test_generate_sql_end_to_end_with_stubbed_model():
    schema = get_schema_description()
    fake_response = "```sql\nSELECT ProductName FROM Products LIMIT 3\n```"
    with patch("src.llm_client.call_ollama", return_value=fake_response):
        sql = generate_sql("Show me 3 products", schema)
    assert sql == "SELECT ProductName FROM Products LIMIT 3"
    # And the resulting SQL should actually be runnable:
    df = run_query(sql)
    assert len(df) == 3


def test_pick_chart_single_value_returns_none():
    df = run_query("SELECT COUNT(*) AS n FROM Customers")
    assert pick_chart(df) is None


def test_pick_chart_category_vs_amount_returns_a_figure():
    df = run_query(
        'SELECT p.ProductName, SUM(od.Quantity) AS Units '
        'FROM "Order Details" od JOIN Products p ON p.ProductID = od.ProductID '
        "GROUP BY p.ProductName ORDER BY Units DESC LIMIT 5"
    )
    assert pick_chart(df) is not None


def test_pick_chart_monthly_series_is_chronological():
    df = run_query(
        "SELECT substr(OrderDate,1,7) AS Month, COUNT(*) AS OrderCount "
        "FROM Orders GROUP BY Month ORDER BY Month LIMIT 12"
    )
    fig = pick_chart(df)
    assert fig is not None
    ax = fig.axes[0]
    # A line chart (not a bar chart re-sorted by value) has exactly one Line2D
    assert len(ax.lines) == 1
